# coding:utf-8

import sys
import io
import os
import time
import re

domain = sys.argv[1]
path = sys.argv[2]

print(domain,path)