# gorse
推荐系统


# 脚本安装
cd /www/server/mdserver-web/plugins && rm -rf gorse && git clone https://github.com/mw-plugin/gorse && cd gorse && rm -rf .git && cd /www/server/mdserver-web/plugins/gorse && bash install.sh install 0.4.15