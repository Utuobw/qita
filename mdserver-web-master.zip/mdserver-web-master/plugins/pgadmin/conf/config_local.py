LOG_FILE = '{$DATA_PATH}/pgadmin4/pgadmin4.log'
SQLITE_PATH = '{$DATA_PATH}/pgadmin4/pgadmin4.db'
SESSION_DB_PATH = '{$DATA_PATH}/pgadmin4/sessions'
STORAGE_DIR = '{$DATA_PATH}/pgadmin4/storage'
AZURE_CREDENTIAL_CACHE_DIR = '{$DATA_PATH}/pgadmin4/azurecredentialcache'
SERVER_MODE = True