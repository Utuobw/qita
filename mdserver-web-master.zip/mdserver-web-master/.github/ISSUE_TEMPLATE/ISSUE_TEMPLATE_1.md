---
name: BUG提交
about: 问题描述 
---

## 什么系统 ?

Debian x, Centos x, Centos x stream, Ubuntu x?

## 错误信息 ?

Ex:
```bash
一个issue，一个问题。多余问题，视情况而答。
```

## 错误截图 ?

...


## 浏览器版本 ?

...


## 软件版本(插件/面板) ?

...
